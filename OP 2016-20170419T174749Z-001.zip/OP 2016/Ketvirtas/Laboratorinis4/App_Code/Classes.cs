﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
namespace Classes
{

    public class Laiskas //: IComparable<Laiskas>, IEquatable<Laiskas>
    {
        public TimeSpan Laikas { get; set; }
        public String Siuntejas { get; set; }
        public String Gavejas { get; set; }
        public int Dydis { get; set; }
   
        public Laiskas(TimeSpan t, string f, string to, int mem)
        {
            Laikas = t;Siuntejas = f; Gavejas = to;Dydis = mem;
        }
        public Laiskas() { }
        //public int CompareTo(Laiskas other)
        //{
        //    if (other == null) return 1;
        //    else
        //        return Siuntejas.CompareTo(other.Siuntejas);
        //}
        //public bool Equals(Laiskas other)
        //{
        //    if (other == null)
        //        return false;
        //    if (this.Siuntejas == other.Siuntejas)
        //        return true;
        //    else
        //        return false;
        //}
        //public override bool Equals(Object obj)
        //{
        //    if (obj == null)
        //        return false;
        //    Laiskas studObj = obj as Laiskas;
        //    if (studObj == null)
        //        return false;
        //    else
        //        return Equals(studObj);
        //}
        //public override int GetHashCode()
        //{
        //    return base.GetHashCode();
        //}

    }


    public class Serveris: IComparable<Serveris>, IEquatable<Serveris>
    {
        public DateTime Diena { get; set; }
        public string Pavadinimas { get; set; }
        public List<Laiskas> VisiLaiskai { get; set; }
        public int Greitis { get; set; }
        public Serveris() { }

        public Serveris(DateTime d, string n, List<Laiskas> e)
        {
            Diena = d; Pavadinimas = n; VisiLaiskai = e;
        }

     
        public void NustatytiGreiti(int speed)
        {
            Greitis = speed;
        }
        public int CompareTo(Serveris other)
        {
            if (other == null) return 1;
            if (Pavadinimas.CompareTo(other.Pavadinimas) != 0)
                return other.Pavadinimas.CompareTo(Pavadinimas);
            else
                return other.Diena.ToString().CompareTo(Diena.ToString());
        }
      
        public bool Equals(Serveris other)
        {
            throw new NotImplementedException();
        }
        //public bool Equals(Serveris other)
        //{
        //    if (other == null)
        //        return false;
        //    if (this.Pavadinimas == other.Pavadinimas)
        //        return true;
        //    else
        //        return false;
        //}
        //public override bool Equals(Object obj)
        //{
        //    if (obj == null)
        //        return false;
        //    Serveris studObj = obj as Serveris;
        //    if (studObj == null)
        //        return false;
        //    else
        //        return Equals(studObj);
        //}
        //public override int GetHashCode()
        //{
        //    return base.GetHashCode();
        //}

      
    }

    public class ServeriuSarasas : IComparable<ServeriuSarasas>, IEquatable<ServeriuSarasas>
    {
        public string Pavadinimas { get; set; }
        public DateTime Data { get; set; }
        public List<int>Valandos { get; set; }//laisvos h

        public ServeriuSarasas() { }
        public ServeriuSarasas(string n, DateTime d, List<int> free)
        {
            Pavadinimas = n; Data = d;Valandos = free;
        }

        public int CompareTo(ServeriuSarasas other)
        {
            if (other == null) return 1;
            if (Pavadinimas.CompareTo(other.Pavadinimas) != 0)
                return other.Pavadinimas.CompareTo(Pavadinimas);
            else
                return other.Data.ToString().CompareTo(Data.ToString());
        }
        public static bool operator >(ServeriuSarasas pirmas, ServeriuSarasas antras)
        {
            return pirmas.CompareTo(antras) == 0;
        }
        public static bool operator <(ServeriuSarasas pirmas, ServeriuSarasas antras)
        {
            return pirmas.CompareTo(antras) == 0;
        }





        //public bool Equals(ServeriuSarasas other)
        //{
        //    if (other == null)
        //        return false;
        //    if (this.Pavadinimas == other.Pavadinimas && this.Data == other.Data)
        //        return true;
        //    else
        //        return false;
        //}
        //public override bool Equals(Object obj)
        //{
        //    if (obj == null)
        //        return false;
        //    ServeriuSarasas studObj = obj as ServeriuSarasas;
        //    if (studObj == null)
        //        return false;
        //    else
        //        return Equals(studObj);
        //}
        //public override int GetHashCode()
        //{
        //    return base.GetHashCode();
        //}
        //public int CompareTo(ServeriuSarasas obj)
        //{
        //    ServeriuSarasas orderToCompare = obj as ServeriuSarasas;
        //    if (orderToCompare.Pavadinimas.CompareTo(Pavadinimas) == 1)
        //    {
        //        return 1;
        //    }
        //    if (orderToCompare.Pavadinimas.CompareTo(Pavadinimas) == -1)
        //    {
        //        return -1;
        //    }

        //    if (orderToCompare.Pavadinimas.CompareTo(Pavadinimas) == 0)
        //    {
        //        if (orderToCompare.Data.CompareTo(Data) == 1)
        //            return 1;
        //        else
        //            return -1;
        //        return 0;
        //    }


        //    return 0;
        //}

        public bool Equals(ServeriuSarasas other)
        {
            throw new NotImplementedException();
        }
    }
}