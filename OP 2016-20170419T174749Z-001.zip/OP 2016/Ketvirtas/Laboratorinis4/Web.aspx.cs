﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Classes;
using System.IO;
using System.Drawing;
using System.Linq;
public partial class Web : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e){ }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SaugotiFailus();
        Dictionary<string, int> ServeriuGreiciai = SkaitytiServerius();
        Label1.Text = "Visų serverių greičiai:";
        SpausdintiServerius(ServeriuGreiciai);
        Label2.Text = "Informacija apie kiekvieną serverį:";
        List<Serveris> Serveriai = SkaitytiServeriuInfo();
        Serveriai.Sort();
        allServersToTables(Serveriai);
        SetSpeeds(Serveriai, ServeriuGreiciai);
        List<ServeriuSarasas> atrinktiServeriai = Atrinkimas(Serveriai);
        atrinktiServeriai.Sort();
        Label3.Text = "Surikiuoti greičiausi serveriai:";
        AtrinktiServeriai(atrinktiServeriai);
        IstrintiFailus(); //istrina nenaudojamus failus

    }
    /// <summary>
    /// Išsaugo failus, kurių reikia programai
    /// </summary>
    public void SaugotiFailus()
    {
        string kelias = "E:\\Ketvirtas\\Laboratorinis4\\Uploads\\";
        foreach (HttpPostedFile failas in FileUpload1.PostedFiles)
        {
            string fileName = failas.FileName;
            kelias += fileName;
            failas.SaveAs(kelias);
            kelias = "E:\\Ketvirtas\\Laboratorinis4\\Uploads\\";
        }
    }
    /// <summary>
    /// Skaito serverių duomenis
    /// </summary>
    /// <returns>Grąžina Dictionary (keys-pavadinimas, values-greičiai)</returns>
    public Dictionary<string, int> SkaitytiServerius()
    {
        Dictionary<string, int> visigreiciai = new Dictionary<string, int>();
        string[] allFiles = Directory.GetFiles("E:\\Ketvirtas\\Laboratorinis4\\Uploads\\");
        foreach (string file in allFiles)
        {
            using (StreamReader reader = new StreamReader(@file))
            {
                string line = reader.ReadLine();
                string test = line.Split(';')[0];
                try
                { DateTime.Parse(test); }
                catch
                {
                    string[] v = line.Split(';');
                    visigreiciai.Add(v[0], int.Parse(v[1]));
                    while ((line = reader.ReadLine()) != null)
                    {
                        v = line.Split(';');
                        visigreiciai.Add(v[0], int.Parse(v[1]));
                    }
                }
            }
        }
        return visigreiciai;
    }
    /// <summary>
    /// Spausdina serverio pavadinimą ir greitį
    /// </summary>
    /// <param name="greiciai">Greičiai, kuriuos spausdina</param>
    public void SpausdintiServerius(Dictionary<string, int> greiciai)
    {
        TableCell cell1 = new TableCell();
        TableCell cell2 = new TableCell();
        cell1.Text = "Serverio Pavadinimas";
        cell2.Text = "Serverio Greitis (B/s)";
        TableRow row = new TableRow();
        row.Cells.Add(cell1);
        row.Cells.Add(cell2);
        TableSpeeds.Rows.Add(row);
        foreach (KeyValuePair<string, int> kvp in greiciai)
        {
            TableCell first = new TableCell();
            TableCell second = new TableCell();
            TableRow row1 = new TableRow();
            first.Text = kvp.Key;
            second.Text = kvp.Value.ToString();
            row1.Cells.Add(first);
            row1.Cells.Add(second);
            TableSpeeds.Rows.Add(row1);
        }
    }
    /// <summary>
    /// Reads all information about servers from uploaded files
    /// </summary>
    /// <returns>All servers in a list.</returns>
    public List<Serveris> SkaitytiServeriuInfo()
    {
        List<Serveris> Serveriai = new List<Serveris>();
        string[] allFiles = Directory.GetFiles("E:\\Ketvirtas\\Laboratorinis4\\Uploads\\");
        foreach (string file in allFiles)
        {
            using (StreamReader reader = new StreamReader(@file))
            {
                string line = reader.ReadLine();
                string test = line.Split(';')[0];
                List<Laiskas> Laiskai = new List<Laiskas>();
                try
                {
                    DateTime.Parse(test);
                    string[] v = line.Split(';');
                    DateTime data = DateTime.Parse(v[0]);
                    string pav = v[1];
                    while ((line = reader.ReadLine()) != null)
                    {
                        v = line.Split(';');
                        Laiskai.Add(new Laiskas(TimeSpan.Parse(v[0]), v[1], v[2], int.Parse(v[3])));
                    }
                    Serveriai.Add(new Serveris(data, pav, Laiskai));
                }
                catch { }
            }
        }
        return Serveriai;
    }
    /// <summary>
    /// Sukuria lentelę ir atspausdina info apie serverius
    /// </summary>
    /// <param name="server">Serveris</param>
    /// <returns>Grąžina info apie tą serverį</returns>
    public Table ServeriuLentele(Serveris server)
    {
        Table customTab = new Table();
        TableCell cell1 = new TableCell();
        cell1.Text = "Data";
        TableCell cell2 = new TableCell();
        cell2.Text = server.Diena.ToString();
        TableCell cell3 = new TableCell();
        cell3.Text = "Pavadinimas";
        TableCell cell4 = new TableCell();
        cell4.Text = server.Pavadinimas;
        TableRow row = new TableRow();
        row.Cells.Add(cell1);
        row.Cells.Add(cell2);
        row.Cells.Add(cell3);
        row.Cells.Add(cell4);
        customTab.Rows.Add(row);
        TableCell atvyk = new TableCell();
        TableCell siunt = new TableCell();
        TableCell gav = new TableCell();
        TableCell atm = new TableCell();
        atvyk.Text = "Atvykimo laikas";
        siunt.Text = "Siuntėjas";
        gav.Text = "Gavėjas";
        atm.Text = "Užimta atmintis";
        TableRow rowSec = new TableRow();
        rowSec.Cells.Add(atvyk);
        rowSec.Cells.Add(siunt);
        rowSec.Cells.Add(gav);
        rowSec.Cells.Add(atm);
        customTab.GridLines = GridLines.Both;
        customTab.Rows.Add(rowSec);
        foreach (Laiskas mail in server.VisiLaiskai)
        {
            TableCell cellTime = new TableCell();
            cellTime.Text = mail.Laikas.ToString();
            TableCell cellFrom = new TableCell();
            cellFrom.Text = mail.Siuntejas;
            TableCell cellTo = new TableCell();
            cellTo.Text = mail.Gavejas;
            TableCell mem = new TableCell();
            mem.Text = mail.Dydis.ToString();
            TableRow rowMail = new TableRow();
            rowMail.Cells.Add(cellTime);
            rowMail.Cells.Add(cellFrom);
            rowMail.Cells.Add(cellTo);
            rowMail.Cells.Add(mem);
            customTab.Rows.Add(rowMail);
        }
        return customTab;
    }
    /// <summary>
    /// Atspausdina serverius
    /// </summary>
    /// <param name="serveriai">Serverių sąrašas</param>
    public void allServersToTables(List<Serveris> serveriai)
    {
        foreach (Serveris server in serveriai)
        {
            Table tempServerTable = ServeriuLentele(server);
            TableCell tempCell = new TableCell();
            tempCell.Controls.Add(tempServerTable);
            TableRow tempRow = new TableRow();
            tempRow.Cells.Add(tempCell);
            tableAllServers.Rows.Add(tempRow);
        }
    }
    /// <summary>
    /// Ištrina failus
    /// </summary>
    public void IstrintiFailus()
    {
        string[] allFiles = Directory.GetFiles("E:\\Ketvirtas\\Laboratorinis4\\Uploads\\");
        foreach (string file in allFiles)
            System.IO.File.Delete(@file);
    }
    /// <summary>
    /// Nustato greičius
    /// </summary>
    /// <param name="serveriai">All servers that you want to set speeds of </param>
    /// <param name="greiciai">Speeds that will be set.</param>
    public void SetSpeeds(List<Serveris> serveriai, Dictionary<string, int> greiciai)
    {
        foreach (Serveris server in serveriai)
        {
            int tryForSpeed = greiciai[server.Pavadinimas];
            server.NustatytiGreiti(tryForSpeed);
        }
    }
    /// <summary>
    ///Randa serverius, kurie perdavė kažkiek baitų
    /// </summary>
    /// <param name="serveriai">serveriu sarasas</param>
    /// <returns>Grąžina serverius</returns>
    public List<ServeriuSarasas> Atrinkimas(List<Serveris> serveriai)
    {
        List<ServeriuSarasas> atrinktiserveriai = new List<ServeriuSarasas>();
        foreach (Serveris ser in serveriai)
        {
            double d = ser.Greitis * 3600.0;
            bool[] aktyviosvalandos = new bool[24];
            foreach (Laiskas l in ser.VisiLaiskai)
            {
                int pradzia = l.Laikas.Hours;
                double laikas = l.Dydis / d;
                if (laikas > 0 && laikas < 1)
                    laikas = 1;
                int val = (int)Math.Truncate(laikas) + pradzia;

                if (val > 24)
                    val = 24;

                for (int i = pradzia; i < val; i++)
                    aktyviosvalandos[i] = true;
            }
            if (aktyviosvalandos.Contains(false))
            {
                List<int> laisvosvalandos = new List<int>();
                for (int i = 0; i < 24; i++)
                {
                    if (aktyviosvalandos[i] == false && laisvosvalandos.Contains(i) == false)
                        laisvosvalandos.Add(i);
                }
                atrinktiserveriai.Add(new ServeriuSarasas(ser.Pavadinimas, ser.Diena, laisvosvalandos));
            }
        }
        return atrinktiserveriai;
    }
    /// <summary>
    ///Išveda atrinktus serverius
    /// </summary>
    /// <param name="server">serverių sąrašas</param>
    public void AtrinktiServeriai(List<ServeriuSarasas> server)
    {
        TableCell cellPavad = new TableCell();
        TableCell cellDiena = new TableCell();
        TableCell cellVal = new TableCell();
        cellPavad.Text = "Serverio Pavadinimas";
        cellDiena.Text = "Diena";
        cellVal.Text = "Valandos, kuriomis nevyko jokių veiksmų";
        TableRow rownew = new TableRow();
        rownew.Cells.Add(cellPavad);
        rownew.Cells.Add(cellDiena);
        rownew.Cells.Add(cellVal);
        SortedTable.Rows.Add(rownew);
        foreach (ServeriuSarasas s in server)
        {
            TableCell cell1 = new TableCell();
            TableCell cell2 = new TableCell();
            TableCell cell3 = new TableCell();
            cell1.Text = s.Pavadinimas;
            cell2.Text = s.Data.ToString();
            string dienos = "";
            foreach (int x in s.Valandos)
                dienos = dienos + x.ToString() + ',';
            cell3.Text = dienos;
            TableRow row = new TableRow();
            row.Cells.Add(cell1);
            row.Cells.Add(cell2);
            row.Cells.Add(cell3);
            SortedTable.Rows.Add(row);
        }
    }
}