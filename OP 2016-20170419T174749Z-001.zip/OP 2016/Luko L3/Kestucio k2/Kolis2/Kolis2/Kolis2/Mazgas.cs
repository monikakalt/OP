﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolis2
{
    class Mazgas
    {
        public Auto duom { get; set; }
        public Mazgas kitas { get; set; }

        public Mazgas()
        {
        }

        public Mazgas(Auto reiksme, Mazgas adr)
        {
            duom = reiksme;
            kitas = adr;
        }
    }
}
