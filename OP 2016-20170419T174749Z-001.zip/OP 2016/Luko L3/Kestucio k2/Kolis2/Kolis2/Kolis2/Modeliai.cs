﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolis2
{
    class Modeliai
    {
        Mazgas d;
        Mazgas pr;
        Mazgas pb;

        public Modeliai()
        {
            d = null;
            pr = null;
            pb = null;
        }

        public Auto GetData()
        {
            return d.duom;
        }

        public void Pr()
        {
            d = pr;
        }
        public void Next()
        {
            d = d.kitas;
        }
        public bool Is()
        {
            return d != null;
        }

        public void AddData(Auto naujas)
        {
            var dd = new Mazgas(naujas, null);
            if (pr != null)
            {
                pb.kitas = dd;
                pb = dd;
            }
            else
            {
                pr = dd;
                pb = dd;
            }
        }

        public void Sorting()
        {
            for (Mazgas d1 = pr; d1 != null; d1 = d1.kitas)
            {
                for (Mazgas d2 = d1; d2 != null; d2 = d2.kitas)
                {
                    if (d1.duom.Price < d2.duom.Price)
                    {
                        Auto temp = d1.duom;
                        d1.duom = d2.duom;
                        d2.duom = temp;
                    }
                    else if (d1.duom.Price == d2.duom.Price)
                    {
                        if (String.Compare(d1.duom.Model, d2.duom.Model) > 0)
                        {
                            Auto temp = d1.duom;
                            d1.duom = d2.duom;
                            d2.duom = temp;
                        }
                    }
                }
            }
        }
    }
}
