﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolis2
{
    class Auto
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public float Price { get; set; }

        public Auto(string make, string model, float price)
        {
            this.Make = make;
            this.Model = model;
            this.Price = price;
        }

        public override string ToString()
        {
            string line = string.Format("{0, -10} | {1, -20} | {2}€", Make, Model, Price);
            return line;
        }
    }
}
