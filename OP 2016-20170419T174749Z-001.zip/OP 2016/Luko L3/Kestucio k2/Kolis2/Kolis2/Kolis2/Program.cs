﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolis2
{
    class Program
    {
        static void Main(string[] args)
        {
            const string Cfd = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Kolis2\\Kolis2\\Duomenys.txt";
            const string Rez = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Kolis2//Kolis2\\Rezultatai.txt";

            if (File.Exists(Rez))
            {
                File.Delete(Rez);
            }

            var Ar = new Modeliai();
            var Br = new Modeliai();

            ReadData(Cfd, Ar);
            WriteData(Ar, Rez);
            CreateBr(Ar, Br);
            WriteData(Br, Rez);
            Br.Sorting();
            WriteData(Br, Rez);
        }

        public static void ReadData(string Cfd, Modeliai Ar)
        {
            string line;
            using (StreamReader input = new StreamReader(Cfd))
            {
                while ((line = input.ReadLine()) != null)
                {
                    string[] value = line.Split(',');
                    string make = value[0];
                    string model = value[1];
                    float price = float.Parse(value[2]);
                    Auto auto = new Auto(make, model, price);
                    Ar.AddData(auto);
                }
            }
        }

        public static void WriteData(Modeliai mod, string Rez)
        {
            string line = ("------------------------------------------------------------------");
            using (StreamWriter output = new StreamWriter(Rez, true))
            {
                output.WriteLine(line);
                for (mod.Pr(); mod.Is(); mod.Next())
                {
                    output.WriteLine(mod.GetData().ToString());
                }
                output.WriteLine(line);
            }
        }

        public static void CreateBr(Modeliai Ar, Modeliai Br)
        {
            Auto mostExpensive = new Auto(null, null, 0);
            for (Ar.Pr(); Ar.Is(); Ar.Next())
            {
                if (Ar.GetData().Price > mostExpensive.Price)
                {
                    mostExpensive = Ar.GetData();
                }
            }
            for (Ar.Pr(); Ar.Is(); Ar.Next())
            {
                if (Ar.GetData().Price > (mostExpensive.Price * 0.75))
                {
                    Br.AddData(Ar.GetData());
                }
            }
        }


    }
}
