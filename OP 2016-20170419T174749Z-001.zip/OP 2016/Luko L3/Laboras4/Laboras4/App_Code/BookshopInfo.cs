﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BookshopInfo
/// </summary>
public class BookshopInfo
{
    public string Author { get; set; }
    public string BookName { get; set; }
    public int MinYear { get; set; }
    public int MaxYear { get; set; }
    public int Price { get; set; }
    public float EditionBought { get; set; }
    public float EditionUnbought { get; set; }
    public float Popularity { get; set; }

	public BookshopInfo(string author, string bookName, int minYear, int maxYear, int price, float editionBought, float editionUnbought)
	{
        this.Author = author;
        this.BookName = bookName;
        this.MinYear = minYear;
        this.MaxYear = maxYear;
        this.Price = price;
        this.EditionBought = editionBought;
        this.EditionUnbought = editionUnbought;
	}

    public override string ToString()
    {
        string line = string.Format("{0, -20}|{1, -30}|{2, -4}|{3, -4}|{4, -5}€|{5, -6}|{6, -6}", Author, BookName, MinYear, MaxYear, Price, EditionBought, EditionUnbought);
        return line;
    }

    public float GetPopularity()
    {
        Popularity = 0;
        float edition = EditionBought + EditionUnbought;
        Popularity = (edition / EditionBought) * 100;
        return Popularity;
    }

    static public bool operator >(BookshopInfo first, BookshopInfo second)
    {
        int nameComp = string.Compare(first.BookName, second.BookName);
        int popComp = 0;
        if (first.GetPopularity() > second.GetPopularity())
        {
            popComp = 1;
        }
        else if (first.GetPopularity() < second.GetPopularity())
        {
            popComp = -1;
        }
        else popComp = 0;
        return nameComp < 1 || nameComp == 0 && popComp < 1;
    }

    static public bool operator <(BookshopInfo first, BookshopInfo second)
    {
        int nameComp = string.Compare(first.BookName, second.BookName);
        int popComp = 0;
        if (first.GetPopularity() < second.GetPopularity())
        {
            popComp = 1;
        }
        else if (first.GetPopularity() > second.GetPopularity())
        {
            popComp = -1;
        }
        else popComp = 0;
        return nameComp > 1 || nameComp == 0 && popComp > 1;
    }
}