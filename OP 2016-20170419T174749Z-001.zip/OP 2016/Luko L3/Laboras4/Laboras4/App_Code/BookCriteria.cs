﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BookCriteria
/// </summary>
public class BookCriteria
{
    public int MinYear { get; set; }
    public int MaxYear { get; set; }
    public int MaxPrice { get; set; }

	public BookCriteria(int minYear, int maxYear, int maxPrice)
	{
        this.MinYear = minYear;
        this.MaxYear = maxYear;
        this.MaxPrice = maxPrice;
	}

    public override string ToString()
    {
        string line = string.Format("nuo: {0, -5}|iki: {1, -5}|{2, -7}€", MinYear, MaxYear, MaxPrice);
        return line;
    }
}