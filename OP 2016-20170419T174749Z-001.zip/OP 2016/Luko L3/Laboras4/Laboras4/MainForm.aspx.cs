﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MainForm : System.Web.UI.Page
{
    List<BookshopInfo> bookList;
    protected void Page_Load(object sender, EventArgs e)
    {
        const string Crit = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Laboras4\\Criteria.txt";
        //const string Rez = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Laboras4\\Rezultatai.txt";

        Dictionary<string, List<BookshopInfo>> BookshopInfo = new Dictionary<string, List<BookshopInfo>>();
        bookList = new List<BookshopInfo>();

        ReadData(BookshopInfo);
        BookCriteria criteria =  ReadCriteria(Crit);
        WriteData(BookshopInfo, criteria);
        CreateBookList(BookshopInfo, criteria, bookList);
        WriteData(bookList, BookListLabel);
        Sorting(bookList);
        WriteData(bookList, SortedBookListLabel);
        //DeleteBookList(bookList);
    }

    public static void ReadData(Dictionary<string, List<BookshopInfo>> BookshopInfo)
    {
        string[] files = Directory.GetFiles(@"C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Laboras4\\Bookshops", "*.txt");
        string line;
        foreach (var file in files)
        {
            using (StreamReader input = new StreamReader(file))
            {
                line = input.ReadLine();
                string bookShopName = line;
                List<BookshopInfo> infoList = new List<BookshopInfo>();
                while ((line = input.ReadLine()) != null)
                {
                    string[] values = line.Split(';');
                    string author = values[0];
                    string bookName = values[1];
                    int minYear = int.Parse(values[2]);
                    int maxYear = int.Parse(values[3]);
                    int price = int.Parse(values[4]);
                    float editionBought = float.Parse(values[5]);
                    float editionUnbought = float.Parse(values[6]);
                    BookshopInfo info = new BookshopInfo(author, bookName, minYear, maxYear, price, editionBought, editionUnbought);
                    infoList.Add(info);
                }
                BookshopInfo.Add(bookShopName, infoList);
            }
        }
    }

    public static BookCriteria ReadCriteria(string CFd)
    {
        string line;
        BookCriteria criteria;
        using (StreamReader input = new StreamReader(CFd))
        {
            line = input.ReadLine();
            string[] values = line.Split(';');
            int minYear = int.Parse(values[0]);
            int maxYear = int.Parse(values[1]);
            int maxPrice = int.Parse(values[2]);
            criteria = new BookCriteria(minYear, maxYear, maxPrice);
        }
        return criteria;
    }

    public void WriteData(Dictionary<string, List<BookshopInfo>> BookshopInfo, BookCriteria criteria)
    {
        string line = "";
        string dash = "--------------------------------------------------------------------------";
        foreach (var shopInfo in BookshopInfo)
        {
            line += "<br>";
            line += shopInfo.Key;
            line += "<br>";
            line += dash;
            line += "<br>";
            for (int i = 0; i < shopInfo.Value.Count; i++)
            {
                line += shopInfo.Value[i].ToString();
                line += "<br>";
            }
            line += dash;
        }
        BookShopLabel.Text = line;

        line = "";
        line += "<br>"; 
        line += "Kriterijai:";
        line += "<br>"; 
        line += criteria.ToString();
        CriteriaLabel.Text = line;
    }
    public static void CreateBookList(Dictionary<string, List<BookshopInfo>> BookshopInfo, BookCriteria criteria, List<BookshopInfo> bookList)
    {
        foreach (var shopInfo in BookshopInfo)
        {
            for (int i = 0; i < shopInfo.Value.Count; i++)
            {
                if ((shopInfo.Value[i].MaxYear <= criteria.MaxYear) && ( shopInfo.Value[i].MinYear >= criteria.MinYear) && (shopInfo.Value[i].Price <= criteria.MaxPrice))
                {
                    bookList.Add(shopInfo.Value[i]);
                }
            }
        }
    }

    public void WriteData(List<BookshopInfo> bookList, Label BookListLabel)
    {
        string line = "";
        line += "<br>";
        foreach (var book in bookList)
        {
            line += book.ToString();
            line += "<br>";
        }
        BookListLabel.Text = line;
    }

    public static void Sorting(List<BookshopInfo> bookList)
    {
        for (int i = 0; i < bookList.Count; i++)
        {
            for (int j = i; j < bookList.Count; j++)
			{
                if (bookList[j] > bookList[i])
                {
                    BookshopInfo temp = bookList[i];
                    bookList[i] = bookList[j];
                    bookList[j] = temp;
                }
			}
        }
    }
    public void DeleteBookList(List<BookshopInfo> bookList)
    {
        int RequestedYear = int.Parse(TextBox1.Text);
        for (int i = 0; i < bookList.Count; i++)
        {
            if (bookList[i].MaxYear >= RequestedYear)
            {
                if (bookList[i].MinYear <= RequestedYear)
                {
                    bookList.RemoveAt(i);
                    i--;
                }
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DeleteBookList(bookList);
        WriteData(bookList, DeletedBookListLabel);
    }
}