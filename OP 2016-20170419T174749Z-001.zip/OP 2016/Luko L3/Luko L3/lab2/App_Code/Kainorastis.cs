﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Klase saugoti kainorascio saraso duomenis.
/// </summary>
public class Kainorastis
{

        //Inicializuojame kintamuosius, laukus, konstruktorius..
		public string CityName { get; private set; }
        public int  ConnectionPrice { get; private set; }
        public int MinutePriceDayTime { get; private set; }
        public int MinutePriceNightTime { get; private set; }

        public Kainorastis(string CityName, int ConnectionPrice, int MinutePriceDayTime, int MinutesPriceNightTime)
        {
            this.CityName = CityName;
            this.ConnectionPrice = ConnectionPrice;
            this.MinutePriceDayTime = MinutePriceDayTime;
            this.MinutePriceNightTime = MinutePriceNightTime;
        }

}