﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Kontrolerio klase valdyti mazgui ir sarasui
/// </summary>
public class Controller<T> : IEnumerable
{


    //Inicializuojame kintamuosius, laukus, konstruktorius..
    Node<T> First;
    Node<T> Iterator;
    Node<T> IteratorNext;
    Node<T> Last;

	public Controller()
	{
        First = null;
        Last = null;
	}






    /// <summary>
    /// Pakeicia nurodyto saraso iraso duomenis.
    /// </summary>
    /// <param name="changingValue">Nauji duomenys</param>
    /// <param name="iterationNum">Keiciame elemento numeris nuo pradzios</param>
    public void changeT(T changingValue, int iterationNum)
    {
        Node<T> Iterator = First;


        for (int i = 0; i < (iterationNum - 1); i++)
            Iterator = Iterator.Address;



        Iterator.setData(changingValue);
    }






    /// <summary>
    /// Prideda nauja irasa prie saraso pabaigos.
    /// </summary>
    /// <param name="addData">Pridedami duomenys</param>
    public void AddToSequence(T addData)
    {

        if (First == null)
        {
            First = new Node<T>();
            First.setData(addData);
            First.setAddress(null);
            Last = First;
        }
        else if (Last == First)
        {
            Last = new Node<T>();
            First.setAddress(Last);
            Last.setData(addData);
            Last.setAddress(null);
        }
        else
        {
                Last.setAddress(new Node<T>());
                Last = Last.Address;
                Last.setData(addData);
                Last.setAddress(null);
        }
        
        
    }




    /// <summary>
    /// Realizuojamas paveldimas interfeisas, kad butu galima naudoti sitam objektui foreach.
    /// </summary>
    /// <returns>Grazina iteruotus klases duomenis</returns>
    public IEnumerator GetEnumerator() {
        Iterator = First;
        while (Iterator != null)
        {
            yield return (T)Iterator.Data;
            Iterator = Iterator.Address;
        }
    }



    /// <summary>
    /// Grazina sios klases objekta kurio pirmas irasas perkeltas per nurodyta skaiciu irasu i prieki nuo pradzios.
    /// </summary>
    /// <param name="throught">Per kiek irasu perkelti i prieki nuo pradzios</param>
    /// <returns>Sios klases objektas perstumtas i prieki nuo pradzios</returns>
    public Controller<T> MoveFromFirst(int throught)
    {
        IteratorNext = First;
        Controller<T> newObject = new Controller<T>();
        for (int i = 0; i < throught; i++)
        {
            IteratorNext = IteratorNext.Address;
        }
        while (IteratorNext != null)
        {
            newObject.AddToSequence(IteratorNext.Data);
            IteratorNext = IteratorNext.Address;
        }

        return newObject;
    }

}