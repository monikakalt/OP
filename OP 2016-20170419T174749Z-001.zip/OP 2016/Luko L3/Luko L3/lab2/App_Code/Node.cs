﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Mazgo klase, valdyti sarasui
/// </summary>
public class Node<T>
{

    //Inicializuojame kintamuosius, laukus, konstruktorius..
    public T Data { get; private set;}
    public Node<T> Address { get; private set; }

    public Node()
    {
        this.Data = Data;
        this.Address = null;
    }
    public Node(T Data) 
    {
        this.Data = Data;
        this.Address = null;
    }
	public Node(T Data, Node<T> Address)
	{
        this.Data = Data;
        this.Address = Address;
	}



    /// <summary>
    /// Nustato saraso irasui nuoroda i sekanti saraso elementa.
    /// </summary>
    /// <param name="Address">Nuoroda i sekanti saraso elemnta</param>
    public void setAddress(Node<T> Address)
    {
        this.Address = Address;
    }

    /// <summary>
    /// Nustato duomenis saraso irasui.
    /// </summary>
    /// <param name="Data">Saraso iraso duomenys</param>
    public void setData(T Data)
    {
        this.Data = Data;
    }




}