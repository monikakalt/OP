﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Klase saugoti abonimentu saraso duomenis.
/// </summary>
public class Abonimentai
{

    //Inicializuojame kintamuosius, laukus, konstruktorius..
    public string name { get; private set; }
    public string lastName { get; private set; }
    public int phoneNumber { get; private set; }
    public string city { get; private set; }
    public int time { get; private set; }
    public string talkingTime { get; private set; }
    public int phoneConPrice { get; private set; }



    public Abonimentai(string name, string lastName, int phoneNumber, string city, int time, string talkingTime)
    {
        this.name = name;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.city = city;
        this.time = time;
        this.talkingTime = talkingTime;
    }


    /// <summary>
    /// Nustato saraso irasui pokalbiu kaina.
    /// </summary>
    /// <param name="price">Nustatoma pokalbiu kaina</param>
    public void setPrice(int price)
    {
        phoneConPrice = price;
    }


}