﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



    public partial class firstPage : System.Web.UI.Page
    {





        /// <summary>
        /// Programos vykdymo pradžia
        /// </summary>
        /// <param name="sender">Pirminė object klasė</param>
        /// <param name="e">Įvykiai</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
        }



        /// <summary>
        /// Programos vykdymas mygtuko paspaudimo pagalba
        /// </summary>
        /// <param name="sender">Pirminė object klasė</param>
        /// <param name="e">Įvykiai</param>
        protected void Button1_Click1(object sender, EventArgs e)
        {
            if (TextBox1.Text != "")
            {
                Session["cityName"] = TextBox1.Text;
                Session["talkingTime"] = Select1.Value;
                Server.Transfer("page.aspx", true);
            }
        }
}