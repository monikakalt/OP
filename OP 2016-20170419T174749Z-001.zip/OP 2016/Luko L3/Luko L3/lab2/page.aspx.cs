﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

//LD_15.Pokalbiai. Fiksuoto telefono ryšio paslaugos tiekėjas mėnesio pabaigoje formuoja ataskaitą, kurioje yra 
//duomenys apie abonentus: pavardė, vardas, abonento telefono numeris, miestas į kurį skambinta, pokalbio pradžios laikas (valanda ir minutė), 
//pokalbio trukmė minutėmis. Nustatykite, kokią pinigų sumą už pokalbius turės mokėti kiekvienas abonentas. Pokalbio tarifas nustatomas pagal 
//pokalbio pradžios laiką. Sudarykite abonentų sąrašą, kurių mokama suma yra didesnė už vidutinę.


//Duomenys:
//•tekstiniame faile U15a.txt yra informacija apie abonentus: pavardė, vardas, abonento telefono numeris, miestas į kurį skambinta, pokalbio pradžios laikas 
//(valanda ir minutė), pokalbio trukmė minutėmis;
//•tekstiniame faile U15b.txt yra pokalbių kainoraštis: miestas, sujungimo kaina, pokalbio minutės kaina dieną (nuo 8 iki 22 val.) ir pokalbio minutės 
//kaina naktį (nuo 22 iki 8 val.).

//Spausdinamas sąrašas turi būti surikiuotas pagal abonentų pavardes abėcėlės tvarka. Sudarykite abonentų, skambinusių į nurodytą miestą nurodytu tarifu 
//(dieną ar naktį) (duomenys įvedami klaviatūra), sąrašą.



public partial class page : System.Web.UI.Page
{




    //Inicializuojame kintamuosius, laukus, konstantas..
    public string cityName { get; private set; }
    public string talkingTime { get; private set; }

    public const string fDataName1 = "c:\\Users\\Lukas\\Desktop\\lab2\\U15a.txt";
    public const string fDataName2 = "c:\\Users\\Lukas\\Desktop\\lab2\\U15b.txt";
    public const string fResultsName = "c:\\Users\\Lukas\\Desktop\\lab2\\R.txt";








    /// <summary>
    /// Programos vykdymo pradžia
    /// </summary>
    /// <param name="sender">Pirminė object klasė</param>
    /// <param name="e">Įvykiai</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        cityName = Session["cityName"].ToString();
        talkingTime = Session["talkingTime"].ToString();


        Controller<Abonimentai> abo = new Controller<Abonimentai>();
        Controller<Kainorastis> kain = new Controller<Kainorastis>();
        readAboniments(fDataName1, abo);
        readPrices(fDataName2, kain);

        
        calculateEveryAbonimentConPrice(abo, kain);
        int paymentAverage = calculateAverage(abo);
        Controller<Abonimentai> biggerThanAverage = foundWhoPaymentBiggerThanAverage(abo, paymentAverage);
        Controller<Abonimentai> specified = specifiedAbo(abo, cityName, talkingTime);
        formRow(abo);
        formRow(biggerThanAverage);
        formRow(specified);

        writeDataToFile(fResultsName, abo, biggerThanAverage, specified, paymentAverage);
        writeDataToScreen(abo, biggerThanAverage, specified, paymentAverage);

    }








    /// <summary>
    /// Isveda gautus rezultatus i ekrana.
    /// </summary>
    /// <param name="abo">Surikiuotas, su pokalbiu mokestciu paskaiciuotas abonimentu sarasas</param>
    /// <param name="biggerThanAverage">Surikiuotas, didesniu nei vidutinis mokestis uz poalbius abonimentu sarasas</param>
    /// <param name="specified">Surikiuotas, pagal nurodymus programus pradzioje atrinktu abonimentu sarasas</param>
    /// <param name="paymentAverage">Vidutinis visu abonimentu pokalbiu mokestis</param>
    private void writeDataToScreen(Controller<Abonimentai> abo, Controller<Abonimentai> biggerThanAverage, Controller<Abonimentai> specified, int paymentAverage)
    {
        string formattedText = "<div class='container'><div class='well'><h1>Programa įvykdyta sėkmingai</h1></div><br/><br/><div class='well'><h2>Lentelė su paskaičiavimais kokią sumą už poklabius turės sumokėti kiekvienas vartotojas</h2></div><table class='table table-hover'>";
        formattedText += "<tr><th>Vardas</th><th>Pavardė</th><th>mob.tel.</th><th>miestas</th><th>mokama suma</th></tr>";
        foreach (Abonimentai item in abo)
            formattedText += "<tr><td>" + item.name + "</td><td>" + item.lastName + "</td><td>" + item.phoneNumber + "</td><td>" + item.city + "</td><td>" + item.phoneConPrice + "</td></tr>";
        formattedText += "</table><br/><br/><br/><br/><br/>";
        formattedText += "<div class='well'><h2>Lentelė su paskaičiavimais, kurie vatotojai moka daugiau negu visu mokamos sumos vidurkis: " + paymentAverage + "</h2></div><table class='table table-hover'>";
        formattedText += "<tr><th>Vardas</th><th>Pavardė</th><th>mob.tel.</th><th>miestas</th><th>mokama suma</th></tr>";
        foreach (Abonimentai item in biggerThanAverage)
            formattedText += "<tr><td>" + item.name + "</td><td>" + item.lastName + "</td><td>" + item.phoneNumber + "</td><td>" + item.city + "</td><td>" + item.phoneConPrice + "</td></tr>";
        formattedText += "</table><br/><br/><br/><br/><br/>";
        formattedText += "<div class='well'><h2>Lentelė su vartotojais, kurių paramentrai (miestas: " + cityName + ", tarifas: " + talkingTime + ") buvo nurodyti programos naudotojo</h2></div><table class='table table-hover'>";
        formattedText += "<tr><th>Vardas</th><th>Pavardė</th><th>mob.tel.</th><th>miestas</th><th>mokama suma</th><th>tarifas</th></tr>";
        foreach (Abonimentai item in specified)
            {
                formattedText += "<tr><td>" + item.name + "</td><td>" + item.lastName + "</td><td>" + item.phoneNumber + "</td><td>" + item.city + "</td><td>" + item.phoneConPrice + "</td><td>" + item.talkingTime + "</td></tr>";
            }
        formattedText += "</table></div>";
        Label1.Text = formattedText;
    }






    /// <summary>
    /// Isveda gautus rezultatus i faila.
    /// </summary>
    /// <param name="fResultsName">Rezultatu failo adresas</param>
    /// <param name="abo">Surikiuotas, su pokalbiu mokestciu paskaiciuotas abonimentu sarasas</param>
    /// <param name="biggerThanAverage">Surikiuotas, didesniu nei vidutinis mokestis uz poalbius abonimentu sarasas</param>
    /// <param name="specified">Surikiuotas, pagal nurodymus programus pradzioje atrinktu abonimentu sarasas</param>
    /// <param name="paymentAverage">Vidutinis visu abonimentu pokalbiu mokestis</param>
    private void writeDataToFile(string fResultsName, Controller<Abonimentai> abo, Controller<Abonimentai> biggerThanAverage, Controller<Abonimentai> specified, int paymentAverage)
    {

        using (StreamWriter writer = new StreamWriter(@fResultsName))
        {
            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            writer.WriteLine("Lentelė su paskaičiavimais kokią sumą už poklabius turės sumokėti kiekvienas vartotojas");
            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            writer.WriteLine("     Vardas       Pavardė      mob.tel.      miestas     mokama suma");
            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            foreach (Abonimentai item in abo)
            {
                writer.WriteLine("{0, 12} {1, 12} {2, 12} {3, 12} {4, 12}", item.name, item.lastName, item.phoneNumber, item.city, item.phoneConPrice);
                writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            }
            writer.WriteLine();
            writer.WriteLine();
            writer.WriteLine();
            writer.WriteLine();
            writer.WriteLine();




            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            writer.WriteLine("Lentelė su paskaičiavimais, kurie vatotojai moka daugiau negu visu mokamos sumos vidurkis: " + paymentAverage);
            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            writer.WriteLine("     Vardas       Pavardė      mob.tel.      miestas     mokama suma");
            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            foreach (Abonimentai item in biggerThanAverage)
            {
                writer.WriteLine("{0, 12} {1, 12} {2, 12} {3, 12} {4, 12}", item.name, item.lastName, item.phoneNumber, item.city, item.phoneConPrice);
                writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            }
            writer.WriteLine();
            writer.WriteLine();
            writer.WriteLine();
            writer.WriteLine();
            writer.WriteLine();



            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            writer.WriteLine("Lentelė su vartotojais, kurių paramentrai (miestas: " + cityName + ", tarifas: " + talkingTime + ") buvo nurodyti programos naudotojo");
            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            writer.WriteLine("     Vardas       Pavardė      mob.tel.      miestas     mokama suma    tarifas");
            writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            foreach (Abonimentai item in specified)
            {
                writer.WriteLine("{0, 12} {1, 12} {2, 12} {3, 12} {4, 12} {5, 12}", item.name, item.lastName, item.phoneNumber, item.city, item.phoneConPrice, item.talkingTime);
                writer.WriteLine("------------------------------------------------------------------------------------------------------------------------------------");
            }

        }

    }








    /// <summary>
    /// Rikiuoja sarasa pagal abonimento pavarde.
    /// </summary>
    /// <param name="abo">Sarasas, kuri reikia surikiuoti</param>
    private void formRow(Controller<Abonimentai> abo)
    {
        int counter = 0;

        foreach (Abonimentai item in abo)
        {
            
            counter++;
            int counterNext = counter;

            Abonimentai iters = item;
            Controller<Abonimentai> naujas = abo.MoveFromFirst(counter);

            foreach (Abonimentai next in naujas)
            {
                counterNext++;
                if ((iters.lastName.CompareTo(next.lastName) == 1) ? true : false)
                {
                    Abonimentai temporary = iters;
                    abo.changeT(next, counter);
                    abo.changeT(temporary, counterNext);
                    iters = next;
                }
            }
        }

        
    }






    /// <summary>
    /// Atrenka abonimentus pagal miesta ir tarifa.
    /// </summary>
    /// <param name="abo">Sarasas is kurio reikia atrinkti abonimentus</param>
    /// <param name="cityName">Miestas pagal kuri reikia atrinkti abonimentus</param>
    /// <param name="talkingTime">Tarifas pagal kuri reikia atrinkti abonimentus</param>
    /// <returns>Atrinkta abonimentu sarasa</returns>
    private Controller<Abonimentai> specifiedAbo(Controller<Abonimentai> abo, string cityName, string talkingTime)
    {

        Controller<Abonimentai> specified = new Controller<Abonimentai>();

        foreach (Abonimentai item in abo)
            if (item.city == cityName && item.talkingTime == talkingTime)
                specified.AddToSequence(item);

        return specified;
    }




    /// <summary>
    /// Suranda abonimentus kuriu mokestis uz pokalbius didesnis nei vidutinis.
    /// </summary>
    /// <param name="abo">Sarasas is kurio reikia atrinkti abonimentus</param>
    /// <param name="paymentAverage">Vidutinis pokalbiu mokestis</param>
    /// <returns>Atrinkta abonimentu sarasa</returns>
    private Controller<Abonimentai> foundWhoPaymentBiggerThanAverage(Controller<Abonimentai> abo, int paymentAverage)
    {

        Controller<Abonimentai> biggerThanAverage = new Controller<Abonimentai>();

        foreach (Abonimentai item in abo)
            if (item.phoneConPrice > paymentAverage)
                biggerThanAverage.AddToSequence(item);

        return biggerThanAverage;

    }






    /// <summary>
    /// Apskaiciuoja abonimentu vidutini pokalbiu mokesti.
    /// </summary>
    /// <param name="abo">Abonimentu sarasas</param>
    /// <returns>Abonimentu vidutini mokesti</returns>
    private int calculateAverage(Controller<Abonimentai> abo)
    {
        int sum = 0, aboCount = 0;

        foreach (Abonimentai item in abo)
        {
            sum += item.phoneConPrice;
            aboCount++;
        }


        return Convert.ToInt16(sum / aboCount);
    }





    /// <summary>
    /// Apskaiciuoja kiekvieno abinimento pokalbiu mokesti.
    /// </summary>
    /// <param name="abo">Abonimentu sarasas</param>
    /// <param name="kain">Kainu sarasas</param>
    private void calculateEveryAbonimentConPrice(Controller<Abonimentai> abo, Controller<Kainorastis> kain)
    {
        foreach (Abonimentai item in abo)
        {
            int price = 0;
            foreach (Kainorastis next in kain)
                if (next.CityName == item.city)
                {
                    price += next.ConnectionPrice;

                    //Dienos laikas
                    if (item.talkingTime == "diena")
                        price += (item.time * next.MinutePriceDayTime);
                    //Nakties laikas
                    else
                        price += (item.time * next.MinutePriceNightTime);
                }
            item.setPrice(price);
        }
    }




    /// <summary>
    /// Nuskaito abonimentus is failo.
    /// </summary>
    /// <param name="fDataName1">Duomenu failo vardas</param>
    /// <param name="abo">Abonimentu sarasas kuri reikia uzpildyti</param>
    private void readAboniments(string fDataName1, Controller<Abonimentai> abo)
    {
        using (StreamReader reader = new StreamReader(@fDataName1))
        {
            string line = null;
            while ((line = reader.ReadLine()) != null)
            {
                string[] parts = new string[line.Split(' ').Length];
                parts = line.Split(' ');
                abo.AddToSequence(new Abonimentai(parts[0], parts[1], Convert.ToInt32(parts[2]), parts[3], Convert.ToInt16(parts[6]), (Convert.ToInt16(parts[4]) > 7 && Convert.ToInt16(parts[4]) < 22 ? "diena" : "naktis")));
            }
        }

    }



    /// <summary>
    /// Nuskaito kainas is failo.
    /// </summary>
    /// <param name="fDataName2">Duomenu failo vardas</param>
    /// <param name="kain">Kainu sarasas kuri reikia uzpildyti</param>
    private void readPrices(string fDataName2, Controller<Kainorastis> kain)
    {

        using (StreamReader reader = new StreamReader(@fDataName2))
        {
            string line = null;
            while ((line = reader.ReadLine()) != null)
           {
                string[] parts = new string[line.Split(' ').Length];
                parts = line.Split(' ');
               kain.AddToSequence(new Kainorastis(parts[0], Convert.ToInt16(parts[1]), Convert.ToInt16(parts[2]), Convert.ToInt16(parts[3])));
            }
       }
    }






}