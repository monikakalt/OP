﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace KD1_Pavyzdys
{
    class Program
    {
        /// <summary>
        /// Laiko studento informaciją
        /// </summary>
        class Studentas
        {
            public string Pavarde { get; private set; }
            public string Vardas { get; private set; }
            public string Grupe { get; private set; }

            List<int> Kreditai;                         // Kreditų sąrašas

            /// <summary>
            /// Nustatantis pagrindinę studento informaciją
            /// </summary>
            /// <param name="pavarde">Pavardė</param>
            /// <param name="vardas">Vardas</param>
            /// <param name="grupe">Grupė</param>
            public Studentas(string pavarde, string vardas, string grupe)
            {
                Pavarde = pavarde;
                Vardas = vardas;
                Grupe = grupe;

                Kreditai = new List<int>();
            }

            /// <summary>
            /// Prideda kreditą į kreditų sąrašą
            /// </summary>
            /// <param name="kreditas">Kreditas</param>
            public void PridetiKredita(int kreditas)
            {
                Kreditai.Add(kreditas);
            }

            /// <summary>
            /// Rekursiškai skaičiuoja kreditų sumą
            /// </summary>
            /// <param name="indeksas">Kredito indeksas(Nenaudoti šaukiant)</param>
            /// <returns>Suma</returns>
            public int KredituSuma(int indeksas = 0)
            {
                int suma = Kreditai[indeksas];

                if (indeksas + 1 < Kreditai.Count)
                {
                    suma += KredituSuma(indeksas + 1);
                }

                return suma;
            }

            public override string ToString()
            {
                string rezultatas = string.Format("{0, -25} {1,-10}", Pavarde + " " + Vardas, Grupe);
                foreach(int kreditas in Kreditai)
                {
                    rezultatas += string.Format("{0, -5}", kreditas);
                }
                return rezultatas;
            }
        }

        /// <summary>
        /// Laiko fakulteto informaciją ir studentų sąrašą
        /// </summary>
        class Fakultetas
        {
            public string Pavadinimas { get; private set; }
            public int KredituKiekis { get; private set; }
            public int ModuliuKiekis { get; private set; }

            List<Studentas> Studentai;                      // Studentų sąrašas

            /// <summary>
            /// Skaito fakulteto informaciją iš failo
            /// </summary>
            /// <param name="failoVardas">Failo vardas</param>
            /// <param name="rezultatai">Rezultatų tekstas</param>
            /// <returns>Fakultetas</returns>
            public static Fakultetas Skaityti(string failoVardas, ref string rezultatai)
            {
                Fakultetas fakultetas;

                using (StreamReader reader = new StreamReader(failoVardas))
                {
                    string line = reader.ReadLine();
                    string[] parts = line.Split(" ".ToArray(), StringSplitOptions.RemoveEmptyEntries);

                    string pavadinimas = parts[0];

                    for (int i = 1; i < parts.Length - 2; i++)
                    {
                        pavadinimas += " " + parts[i];
                    }

                    int kredituKiekis = int.Parse(parts[parts.Length - 2]);
                    int moduliuKiekis = int.Parse(parts[parts.Length - 1]);

                    fakultetas = new Fakultetas(pavadinimas, kredituKiekis, moduliuKiekis);

                    while ((line = reader.ReadLine()) != null)
                    {
                        parts = line.Split(" ".ToArray(), StringSplitOptions.RemoveEmptyEntries);

                        Studentas studentas = new Studentas(parts[0], parts[1], parts[2]);

                        for (int i = 3; i < parts.Length; i++)
                        {
                            studentas.PridetiKredita(int.Parse(parts[i]));
                        }

                        fakultetas.PridetiStudenta(studentas);
                    }
                }

                rezultatai += "\"" + failoVardas + "\"\n" + fakultetas + "\n\n";

                return fakultetas;
            }

            /// <summary>
            /// Nustato pagrindinę fakulteto informaciją
            /// </summary>
            /// <param name="pavadinimas">Fakultetas</param>
            /// <param name="kredituKiekis">Kreditų kiekis</param>
            /// <param name="moduliuKiekis">Modulių kiekis</param>
            public Fakultetas(string pavadinimas, int kredituKiekis,
                int moduliuKiekis)
            {
                Pavadinimas = pavadinimas;
                KredituKiekis = kredituKiekis;
                ModuliuKiekis = moduliuKiekis;

                Studentai = new List<Studentas>();
            }

            /// <summary>
            /// Prideda studentą į sąrašą
            /// </summary>
            /// <param name="studentas">Studentas</param>
            public void PridetiStudenta(Studentas studentas)
            {
                Studentai.Add(studentas);
            }
            
            /// <summary>
            /// Rikiuoja studentus burbuliuko algoritmu
            /// </summary>
            public void RikiuotiStudentusBurbuliuku()
            {
                for (int i = 0; i < Studentai.Count - 1; i++)
                {
                    for (int j = 0; j < Studentai.Count - 1; j++)
                    {
                        if (Studentai[j].Grupe.CompareTo(Studentai[j + 1].Grupe) > 0
                            || Studentai[j].Grupe.CompareTo(Studentai[j + 1].Grupe) == 0
                            && Studentai[j].Pavarde.CompareTo(Studentai[j + 1].Pavarde) > 0)
                        {
                            Studentas laikinas = Studentai[j];
                            Studentai[j] = Studentai[j + 1];
                            Studentai[j + 1] = laikinas;
                        }
                    }
                }
            }

            /// <summary>
            /// Rikiuoja studentus išrinkimo algoritmu
            /// </summary>
            public void RikiuotiStudentusIsrinkimu()
            {
               // this.Studentai.OrderBy(studentas => studentas.Grupe).ThenBy(studentas => studentas.Pavarde);

                for (int i = 0; i < Studentai.Count - 1; i++)
                {
                    for (int j = i + 1; j < Studentai.Count; j++)
                    {
                        if (Studentai[i].Grupe.CompareTo(Studentai[j].Grupe) > 0
                            || Studentai[i].Grupe.CompareTo(Studentai[j].Grupe) == 0
                            && Studentai[i].Pavarde.CompareTo(Studentai[j].Pavarde) > 0)
                        {
                            Studentas laikinas = Studentai[i];
                            Studentai[i] = Studentai[j];
                            Studentai[j] = laikinas;
                        }
                    }
                }
            }

            /// <summary>
            /// Spausdina studentų sąrašą į konsolę
            /// </summary>
            public void SpausdintiStudentus()
            {
                foreach (Studentas studentas in Studentai)
                {
                    Console.WriteLine(studentas);
                }
            }

            /// <summary>
            /// Atrenka per daug kreditų turinčius studentus
            /// </summary>
            /// <returns>Studentų sąrašas</returns>
            public List<Studentas> AtrinktiStudentus()
            {
                List<Studentas> rezultatai = new List<Studentas>();
                foreach (Studentas studentas in Studentai)
                {
                    if(studentas.KredituSuma() > KredituKiekis)
                    {
                        rezultatai.Add(studentas);
                    }
                }
                return rezultatai;
            }

            /// <summary>
            /// Šalina pateiktus studentus iš sąrašo
            /// </summary>
            /// <param name="sarasas"></param>
            public void SalintiStudentus(List<Studentas> sarasas)
            {
                foreach(Studentas studentas in sarasas)
                {
                    Studentai.Remove(studentas);
                }
            }

            /// <summary>
            /// Gražina studentus, viršijusius nurodytą kreditų kiekį
            /// </summary>
            /// <param name="fakultetas">Fakultetas</param>
            /// <param name="kredituKiekis">Kreditų kiekis</param>
            /// <returns>Studentų kiekis</returns>
            public static int operator >(Fakultetas fakultetas, int kredituKiekis)
            {
                int studentuKiekis = 0;
                foreach(Studentas studentas in fakultetas.Studentai)
                {
                    if(studentas.KredituSuma() > kredituKiekis)
                    {
                        studentuKiekis++;
                    }
                }
                return studentuKiekis;
            }

            /// <summary>
            /// Gražina studentus, turinčius mažiau nei nurodytą kreditų kiekį
            /// </summary>
            /// <param name="fakultetas">Fakultetas</param>
            /// <param name="kredituKiekis">Kreditų kiekis</param>
            /// <returns>Studentų kiekis</returns>
            public static int operator <(Fakultetas fakultetas, int kredituKiekis)
            {
                int studentuKiekis = 0;
                foreach (Studentas studentas in fakultetas.Studentai)
                {
                    if (studentas.KredituSuma() < kredituKiekis)
                    {
                        studentuKiekis++;
                    }
                }
                return studentuKiekis;
            }

            /// <summary>
            /// Gražina studentus, turinčius nurodytą kreditų kiekį
            /// </summary>
            /// <param name="fakultetas">Fakultetas</param>
            /// <param name="kredituKiekis">Kreditų kiekis</param>
            /// <returns>Studentų kiekis</returns>
            public static int operator ==(Fakultetas fakultetas, int kredituKiekis)
            {
                int studentuKiekis = 0;
                foreach (Studentas studentas in fakultetas.Studentai)
                {
                    if (studentas.KredituSuma() == kredituKiekis)
                    {
                        studentuKiekis++;
                    }
                }
                return studentuKiekis;
            }

            /// <summary>
            /// Gražina studentus, neturinčius nurodyto kreditų kiekio
            /// </summary>
            /// <param name="fakultetas">Fakultetas</param>
            /// <param name="kredituKiekis">Kreditų kiekis</param>
            /// <returns>Studentų kiekis</returns>
            public static int operator !=(Fakultetas fakultetas, int kredituKiekis)
            {
                return (fakultetas > kredituKiekis) + (fakultetas < kredituKiekis);
            }

            public override bool Equals(object obj)
            {
                return base.Equals(obj);
            }

            public override int GetHashCode()
            {
                return base.GetHashCode();
            }

            public override string ToString()
            {
                string rezultatas = Pavadinimas + " " + KredituKiekis + " " + ModuliuKiekis;
                foreach(Studentas studentas in Studentai)
                {
                    rezultatas += "\n" + studentas;
                }
                return rezultatas;
            }
        }

        static void Main(string[] args)
        {
            string rezultatai = "DUOMENYS\n\n";

            Fakultetas fakultetas1 = Fakultetas.Skaityti("Duom1.txt", ref rezultatai);
            Fakultetas fakultetas2 = Fakultetas.Skaityti("Duom2.txt", ref rezultatai);

            rezultatai += "FAKULTETŲ PALYGINIMAS\n\n";

            PalygintiFakultetus(fakultetas1, fakultetas2, ref rezultatai);

            fakultetas1.SalintiStudentus(fakultetas1.AtrinktiStudentus());
            fakultetas2.SalintiStudentus(fakultetas2.AtrinktiStudentus());

            rezultatai += "\n\nREZULTATAI\n\n" + fakultetas1 + "\n\n" + fakultetas2;

            Rasyti("Rezultatai.txt", rezultatai);
        }

        /// <summary>
        /// Palygina fakultetų kreditus pagal kreditų kiekį
        /// </summary>
        /// <param name="fakultetas1">Pirmasis fakultetas</param>
        /// <param name="fakultetas2">Antrasis fakultetas</param>
        /// <param name="rezultatai">Rezultatų tekstas</param>
        static void PalygintiFakultetus(Fakultetas fakultetas1,
            Fakultetas fakultetas2, ref string rezultatai)
        {
            // Mažiau
            int studentuKiekis1 = fakultetas1 < fakultetas1.KredituKiekis;
            int studentuKiekis2 = fakultetas2 < fakultetas2.KredituKiekis;
            
            if (studentuKiekis1 > studentuKiekis2)
            {
                rezultatai += string.Format("{0} fakultete yra daugiau studentų, kurie turi mažiau kreditų nei reikalauja fakultetas.", fakultetas1.Pavadinimas);
            }
            else if(studentuKiekis1 < studentuKiekis2)
            {
                rezultatai += string.Format("{0} fakultete yra daugiau studentų, kurie turi mažiau kreditų nei reikalauja fakultetas.", fakultetas2.Pavadinimas);
            }
            else
            {
                rezultatai += "Abiejuose fakultetuose yra vienodas skaičius studentų, kurie turi mažiau kreiditų nei reikalauja fakultetas.";
            }

            // Lygu
            studentuKiekis1 = fakultetas1 == fakultetas1.KredituKiekis;
            studentuKiekis2 = fakultetas2 == fakultetas2.KredituKiekis;

            if (studentuKiekis1 > studentuKiekis2)
            {
                rezultatai += string.Format("\n{0} fakultete yra daugiau studentų, kurie turi reikalaujamą kreditų skaičių.", fakultetas1.Pavadinimas);
            }
            else if (studentuKiekis1 < studentuKiekis2)
            {
                rezultatai += string.Format("\n{0} fakultete yra daugiau studentų, kurie turi reikalaujamą kreditų skaičių.", fakultetas2.Pavadinimas);
            }
            else
            {
                rezultatai += "\nAbiejuose fakultetuose yra vienodas skaičius studentų, kurie turi reikalaujamą kreditų skaičių.";
            }

            // Daugiau
            studentuKiekis1 = fakultetas1 > fakultetas1.KredituKiekis;
            studentuKiekis2 = fakultetas2 > fakultetas2.KredituKiekis;

            if (studentuKiekis1 > studentuKiekis2)
            {
                rezultatai += string.Format("\n{0} fakultete yra daugiau studentų, kurie turi daugiau kreditų nei reikalauja fakultetas.", fakultetas1.Pavadinimas);
            }
            else if (studentuKiekis1 < studentuKiekis2)
            {
                rezultatai += string.Format("\n{0} fakultete yra daugiau studentų, kurie turi daugiau kreditų nei reikalauja fakultetas.", fakultetas2.Pavadinimas);
            }
            else
            {
                rezultatai += "\nAbiejuose fakultetuose yra vienodas skaičius studentų, kurie turi daugiau kreditų nei reikalauja fakultetas.";
            }
        }

        /// <summary>
        /// Rašo rezultatų failą
        /// </summary>
        /// <param name="failoVardas">Failo vardas</param>
        /// <param name="rezultatai">Rezultatų tekstas</param>
        static void Rasyti(string failoVardas, string rezultatai)
        {
            File.WriteAllText(failoVardas, rezultatai);
        }
    }
}
