﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
namespace Classes
{
    /// <summary>
    /// KLasė su laiškų informacija
    /// </summary>
    public class Laiskas
    {
        public TimeSpan Laikas { get; set; }
        public String Siuntejas { get; set; }
        public String Gavejas { get; set; }
        public int Dydis { get; set; }
        /// <summary>
        /// Konstruktorius
        /// </summary>
        /// <param name="t-laikas"></param>
        /// <param name="f-Siuntėjas"></param>
        /// <param name="to-Gavėjas"></param>
        /// <param name="mem-Dydis"></param>
        public Laiskas(TimeSpan t, string f, string to, int mem)
        {
            Laikas = t; Siuntejas = f; Gavejas = to; Dydis = mem;
        }
        /// <summary>
        /// Tuščias konstruktorius
        /// </summary>
        public Laiskas() { }
    }
    /// <summary>
    /// Klasė su serverių info
    /// </summary>
    public class Serveris
    {
        public DateTime Diena { get; set; }
        public string Pavadinimas { get; set; }
        public List<Laiskas> VisiLaiskai { get; set; }
        public int Greitis { get; set; }
        public Serveris() { }
        /// <summary>
        /// Konstruktorius
        /// </summary>
        /// <param name="d-diena"></param>
        /// <param name="Pavadinimas"></param>
        /// <param name="e"></param>
        public Serveris(DateTime d, string n, List<Laiskas> e)
        { Diena = d; Pavadinimas = n; VisiLaiskai = e; }
        /// <summary>
        /// Nustato greitį 
        /// </summary>
        /// <param name="speed">Greitis</param>
        public void NustatytiGreiti(int speed)
        { Greitis = speed;}
    }
    /// <summary>
    /// Klasė su serverių sąrašu
    /// </summary>
    public class ServeriuSarasas : IComparable<ServeriuSarasas>, IEquatable<ServeriuSarasas>
    {
        public string Pavadinimas { get; set; }
        public DateTime Data { get; set; }
        public List<int> Valandos { get; set; }//laisvos h
        public ServeriuSarasas() { }
        /// <summary>
        /// Konstruktorius
        /// </summary>
        /// <param name="n">Pavadinimas</param>
        /// <param name="d">Data</param>
        /// <param name="free">Laisvų valandų listas</param>
        public ServeriuSarasas(string n, DateTime d, List<int> free)
        { Pavadinimas = n; Data = d; Valandos = free; }
        /// <summary>
        /// Palyginimas
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public int CompareTo(ServeriuSarasas other)
        {
            if (other == null) return 1;
            if (Pavadinimas.CompareTo(other.Pavadinimas) != 0)
                return Pavadinimas.CompareTo(other.Pavadinimas);
            else
                return Data.ToString().CompareTo(other.Data.ToString());
        }
        /// <summary>
        /// Palyginimo užklojimas
        /// </summary>
        /// <returns></returns>
        public static bool operator >(ServeriuSarasas pirmas, ServeriuSarasas antras)
        { return pirmas.CompareTo(antras) == 0; }
        /// <summary>
        /// Palyginimo užklojimas
        /// </summary>
        /// <returns></returns>
        public static bool operator <(ServeriuSarasas pirmas, ServeriuSarasas antras)
        { return pirmas.CompareTo(antras) == 0; }
        /// <summary>
        /// Palyginimo užklojimas
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(ServeriuSarasas other)
        { throw new NotImplementedException(); }
    }
}