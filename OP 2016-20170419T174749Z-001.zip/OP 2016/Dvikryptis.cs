﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace u_duotys
{
    //Buvo mano egzamino užduotis.
    //Buvo dvikryptis sąrašas, duoti realiojo tipo skaičiai. Reikėjo padaryti skaičių šalinimą, kurie yra lygus nuliui.

    class Dvikryptis
    {
    }

    //klasė, kuri laiko visus duomenis
    public class Skaičiukai
    {
        public int Skaiciai { get; set; }

        Skaičiukai() { }

        public Skaičiukai(int skaiciai)
        {
            Skaiciai = skaiciai;
        }
    }

    //Mazgo klasė
    public sealed class Mazgas
    {
        public int Duomenys { get; set; }
        public Mazgas Dešine { get; set; }
        public Mazgas Kaire { get; set; }

        public Mazgas(int duomenys, Mazgas desine, Mazgas kaire)
        {
            Duomenys = duomenys;
            Dešine = desine;
            Kaire = kaire;
        }
    }

    //Sąrašo klasė
    public sealed class Sąrašas
    {
        private Mazgas pr; //pradžios elementas
        private Mazgas pb; //pabaigos elementas
        private Mazgas pre;
        private Mazgas pab;
        private Mazgas d;

        public Sarasas()
        {
            pr = new Mazgas(new Skaičiukai(), null, null);
            pb = new Mazgas(new Skaičiukai(), pr, null);
            pre = pr;
            pr.Desine = pb;
            pab = pb;
            d = null;
        }

        //šalinimo metodas
        public void Šalinti(Mazgas šalinamas)
        {
            for (Mazgas mazgas = pr; mazgas != null; mazgas = mazgas.Dešine)
            {
                if (mazgas.Duomenys == 0)
                {
                    Mazgas šalinamas = mazgas.Dešine;
                    mazgas.Duomenys = šalinamas.Duomenys;
                    šalinamas = null;
                }
            }

            for (Mazgas mazgas = pr; mazgas != null; mazgas = mazgas.Kaire)
            {
                if (mazgas.Duomenys == 0)
                {
                    Mazgas šalinamas = mazgas.Kaire;
                    mazgas.Duomenys = šalinamas.Duomenys;
                    šalinamas = null;
                }
            }
        }

        //Antras klausimas, deja linq nepamenu :/

        //Trečias klausimas

        //1.Delegato sukūrimo eiga.
        /* Pirmiausia sukuriamas delegatas, poto delegato objektas, 
        dar vėliau metodas priskyrimui ir tik tada metodas iškviečiantis delegatą. */

        //2.Ar galima rašyti catch sakinius bet kokia tvarka? Atsakymą pagrįskite. 
        /*Ne negalima. Viena, try blokui gali būti užrašyta vienas arba keli catch blokai 
        (dėl to, kad betarpiškiai už try bloko rašomas catch blokas) bei daugeliu atveju pati 
        išimtis generuojama vykdant throw sakinį. Šio tipo sakiniai rašomi try bloke. 
        Vadinasi catch blokų turi būti tiek, kiek skirtingų tipų išimčių apibrėžta throw sakiniuose.*/

        //3.Kokius žinote bendrinius sisteminius delegatus? Kam šie delegatai skirti? 
        /*Action<> -  naudojamas inkapsuliuoti metodą kuris turi vieną parametrą ir negražina jokios reikšmės.
        Func<> - naudojamas inkapsuliuoti metodą, kuris turi vieną parametą ir gražiną reikšmę būtent to tipo kuris yra nurodytasparametruose.*/

        //4. Kažkas buvo su T ir T?. Lyg klausimas ar jos vienodos ar ne.. ?


    }


}
