﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
namespace Classes
{
    public class Laiskas
    {
        public TimeSpan Laikas { get; set; }
        public String Siuntejas { get; set; }
        public String Gavejas { get; set; }
        public int Dydis { get; set; }  
        public Laiskas(TimeSpan t, string f, string to, int mem)
        {
            Laikas = t;Siuntejas = f; Gavejas = to;Dydis = mem;
        }
        public Laiskas() { }
    }
    public class Serveris
    {
        public DateTime Diena { get; set; }
        public string Pavadinimas { get; set; }
        public List<Laiskas> VisiLaiskai { get; set; }
        public int Greitis { get; set; }
        public Serveris() { }
        public Serveris(DateTime d, string n, List<Laiskas> e)
        {  Diena = d; Pavadinimas = n; VisiLaiskai = e; }
        public void NustatytiGreiti(int speed)
        {
            Greitis = speed;
        }
    }

    public class ServeriuSarasas
    {
        public string Pavadinimas { get; set; }
        public DateTime Data { get; set; }
        public List<int>Valandos { get; set; }//laisvos h

        public ServeriuSarasas() { }
        public ServeriuSarasas(string n, DateTime d, List<int> free)
        { Pavadinimas = n; Data = d;Valandos = free;}

    }
}