﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _2
{
    class Auto
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public float Price { get; set; }

        public Auto(string make, string model, float price)
        {
            this.Make = make;
            this.Model = model;
            this.Price = price;
        }
        public override string ToString()
        {
            string line = string.Format("{0, -10} | {1, -20} | {2}€", Make, Model, Price);
            return line;
        }
        public static bool operator >(Auto a, Auto b)
        {
            return a.Price > b.Price;
        }
        public static bool operator <(Auto a, Auto b)
        {
            return !(a.Price > b.Price);
        }
    }
    sealed class Mazgas
    {
        public Auto duom { get; set; }
        public Mazgas kaire { get; set; }
        public Mazgas desine { get; set; }

        public Mazgas(Auto reiksme, Mazgas adrk, Mazgas adrd)
        {
            duom = reiksme;
            kaire = adrk;
            desine = adrd;
        }
    }
    sealed class Modeliai
    {
        private Mazgas d;
        private Mazgas pr;
        private Mazgas pb;

        public Modeliai()
        {
            d = null;
            pr = null;
            pb = null;
        }
        public Auto GetData()
        {
            return d.duom;
        }
        public void Pr()
        {
            d = pr;
        }
        public void Pb()
        {
            d = pb;
        }
        public void Nextk()
        {
            d = d.kaire;
        }
        public void Nextd()
        {
            d = d.desine;
        }
        public bool Is()
        {
            return d != null;
        }
        /*
        SARASO PERZIURE

            NUO PRADZIOS
            for (Mazgas d = pr; d != null; d = d.desine)
            {
                d.duom
            }

            NUO PABAIGOS
            for (Mazgas d = pB; d != null; d = d.kaire)
            {
                d.duom
            }

        PIRMOJO ELEMENTO SALINIMAS

            dd = pr;
            pr = pr.desine;
            pr.kaire = null;
            dd = null;

        VIDURINIO ELEMENTO SALINIMAS
            salinti.kaire.desine = salinti.desine;
            salinti.desine.kaire = salinti.kaire;
            salinti = null;

        */
        public void RemoveElement(Mazgas dd) // Elemento salinimas
        {
            if (dd == pr) pr = pr.desine;
            if (dd == pb) pb = pb.kaire;

            if (dd.kaire != null)
                dd.kaire.desine = dd.desine;

            if (dd.desine != null)
                dd.desine.kaire = dd.kaire;

            dd = null;
        }
        public void RemoveAllList() // Saraso naikinimas
        {
            while (pr != null)
            {
                d = pr;
                pr = pr.desine;
                d = null;
            }
            pb = d = pr;
        }
        public void AddElement(Mazgas priesIterpti, Mazgas iterpti) // Inforamcijos iterpimnas saraso viduje
        {           
            if (priesIterpti == null) return;

            iterpti.desine = priesIterpti.desine;
            iterpti.kaire = priesIterpti;
            priesIterpti.desine.kaire = iterpti;
            priesIterpti.desine = iterpti;
        }
        public void AddData(Auto naujas) // Iterpimas tiesiogine tvarka
        {
            var dd = new Mazgas(naujas, pb, null);
            if (pr != null)
            {
                pb.desine = dd;
            }
            else
            {
                pr = dd;
            }
            pb = dd;
        }
        public void AddData2(Auto naujas) // Iterpimas atvirkstine tvarka
        {
            var dd = new Mazgas(naujas, null, pr);
            if (pr != null)
            {
                pr.kaire = dd;
            }
            else
            {
                pb = dd;
            }
            pr = dd;
        }
        public void Sorting() // Rikiavimas isrinkimo budu
        {
            for (Mazgas d1 = pr; d1 != null; d1 = d1.desine)
            {
                for (Mazgas d2 = d1; d2 != null; d2 = d2.desine)
                {
                    if (d1.duom.Price < d2.duom.Price)
                    {
                        Auto temp = d1.duom;
                        d1.duom = d2.duom;
                        d2.duom = temp;
                    }
                    else if (d1.duom.Price == d2.duom.Price)
                    {
                        if (String.Compare(d1.duom.Model, d2.duom.Model) > 0)
                        {
                            Auto temp = d1.duom;
                            d1.duom = d2.duom;
                            d2.duom = temp;
                        }
                    }
                }
            }
        }
        public void Sorting2() // Rikiavimas burbuliuko budu
        {
            if (pr == null) return; // Jei sarasas tuscias, tai nere ko ir rikiuoti
            bool keista = true;

            while (keista)
            {
                keista = false;
                var pra = pr;
                while (pra.desine != null)
                {
                    if (pra.duom > pra.desine.duom)
                    {
                        Auto A = pra.duom;
                        pra.duom = pra.desine.duom;
                        pra.desine.duom = A;
                        keista = true;
                    }
                    pra = pra.desine;
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            const string Cfd = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Kolis2\\Kolis2\\Duomenys.txt";
            const string Rez = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Kolis2//Kolis2\\Rezultatai.txt";

            if (File.Exists(Rez))
            {
                File.Delete(Rez);
            }

            var Ar = new Modeliai();
            var Br = new Modeliai();

            //ReadData(Cfd, Ar);
            //WriteData(Ar, Rez);
            //CreateBr(Ar, Br);
            //WriteData(Br, Rez);
            //Br.Sorting();
            //WriteData(Br, Rez);
        }
    }
}
