﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _1
{
    class Auto
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public float Price { get; set; }

        public Auto(string make, string model, float price)
        {
            this.Make = make;
            this.Model = model;
            this.Price = price;
        }
        public override string ToString()
        {
            string line = string.Format("{0, -10} | {1, -20} | {2}€", Make, Model, Price);
            return line;
        }
        public static bool operator > (Auto a, Auto b)
        {
            return a.Price > b.Price;
        }
        public static bool operator < (Auto a, Auto b)
        {
            return !(a.Price > b.Price);
        }
    }
    sealed class Mazgas
    {
        public Auto duom { get; set; }
        public Mazgas kitas { get; set; }

        public Mazgas()
        {
        }

        public Mazgas(Auto reiksme, Mazgas adr)
        {
            duom = reiksme;
            kitas = adr;
        }
    }
    sealed class Modeliai
    {
        private Mazgas d;
        private Mazgas pr;
        private Mazgas pb;

        public Modeliai()
        {
            d = null;
            pr = null;
            pb = null;
        }
        public Auto GetData()
        {
            return d.duom;
        }

        public void Pr()
        {
            d = pr;
        }
        public void Next()
        {
            d = d.kitas;
        }
        public bool Is()
        {
            return d != null;
        }
        /*
        INFORMACIJOS DALIU SUKEITIMAS VIETOMIS

            int k = s1.duom;
            s1.duom = s2.duom;
            s2.duom = k;

        PIRMOJO ELEMENTO SALINIMAS

            pr = pr.kitas;

        */
        public void RemoveElement(Mazgas salinti) // Elemento salinimas
        {
            Mazgas priesSalinti = null;

            for (Pr(); Is(); Next())
            {
                if (d.kitas == salinti) // surandamas pries salinama elementa esamas saraso narys
                {
                    priesSalinti = d;
                }
            }

            if (priesSalinti == null) return;

            priesSalinti.kitas = salinti.kitas; // pakeiciamos saraso rodykles
            salinti = null;
        }
        public void RemoveAllList() // Saraso naikinimas
        {
            while (pr != null)
            {
                d = pr;
                pr = pr.kitas;
                d = null;
            }
            pb = d = pr;
        }
        public void AddElement(Mazgas priesIterpti, Mazgas iterpti) // Inforamcijos iterpimnas saraso viduje
        {
            if (priesIterpti == null) return;

            iterpti.kitas = priesIterpti.kitas;
            priesIterpti.kitas = iterpti; // pakeiciamos saraso rodykles
        }
        public void AddData(Auto naujas) // Iterpimas tiesiogine tvarka
        {
            var dd = new Mazgas(naujas, null);
            if (pr != null)
            {
                pb.kitas = dd;
                pb = dd;
            }
            else
            {
                pr = dd;
                pb = dd;
            }
        }
        public void AddData2(Auto naujas) // Iterpimas atvirkstine tvarka
        {
            pr = new Mazgas(naujas, pr);
        }
        public void Sorting() // Rikiavimas isrinkimo budu
        {
            for (Mazgas d1 = pr; d1 != null; d1 = d1.kitas)
            {
                for (Mazgas d2 = d1; d2 != null; d2 = d2.kitas)
                {
                    if (d1.duom.Price < d2.duom.Price)
                    {
                        Auto temp = d1.duom;
                        d1.duom = d2.duom;
                        d2.duom = temp;
                    }
                    else if (d1.duom.Price == d2.duom.Price)
                    {
                        if (String.Compare(d1.duom.Model, d2.duom.Model) > 0)
                        {
                            Auto temp = d1.duom;
                            d1.duom = d2.duom;
                            d2.duom = temp;
                        }
                    }
                }
            }
        }
        public void Sorting2() // Rikiavimas burbuliuko budu
        {
            if (pr == null) return; // Jei sarasas tuscias, tai nere ko ir rikiuoti
            bool keista = true;

            while (keista)
            {
                keista = false;
                var pra = pr;
                while (pra.kitas != null)
                {
                    if (pra.duom > pra.kitas.duom)
                    {
                        Auto A = pra.duom;
                        pra.duom = pra.kitas.duom;
                        pra.kitas.duom = A;
                        keista = true;
                    }
                    pra = pra.kitas;
                }
            }
        }
    }
    class Program
    {
        public delegate int Dupar(int xx, int yy);

        static void Main(string[] args)
        {
            Dupar deleg = new Dupar(paprasta.Prideti);
            Console.WriteLine(" 5 + 4 = " + deleg(5, 4));

            const string Cfd = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Kolis2\\Kolis2\\Duomenys.txt";
            const string Rez = "C:\\Users\\Kestutis\\Documents\\Visual Studio 2012\\Projects\\Kolis2//Kolis2\\Rezultatai.txt";

            if (File.Exists(Rez))
            {
                File.Delete(Rez);
            }

            var Ar = new Modeliai();
            var Br = new Modeliai();

           

        //ReadData(Cfd, Ar);
        //WriteData(Ar, Rez);
        //CreateBr(Ar, Br);
        //WriteData(Br, Rez);
        //Br.Sorting();
        //WriteData(Br, Rez);
    }
}
}
