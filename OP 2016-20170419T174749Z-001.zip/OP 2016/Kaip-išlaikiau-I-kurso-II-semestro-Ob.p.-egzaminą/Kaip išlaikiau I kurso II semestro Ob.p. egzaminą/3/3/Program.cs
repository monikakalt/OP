﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Linq.Expressions;

namespace _3
{
    static class Ispletimas // Išplėtimo metodai
    {
        public static int AtvirksciasSk(this int sk) // Išplėtimo metodai
        {
            char[] skaiciai = sk.ToString().ToCharArray();
            Array.Reverse(skaiciai);
            string eilSkaic = new string(skaiciai);
            return int.Parse(eilSkaic);
        }
        public static void SpausdIrSignal(this IEnumerable iter)
        {
            foreach (var punkt in iter)
            {
                Console.WriteLine(punkt);
                Console.Beep();
            }
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            int skaic = 123456789;
            int[] sveiki = { 15, 181, 20 };
            string[] duom = { "Ejo", "keliuku", "ežiukas" };

            Console.WriteLine("Sveikasis " + skaic);
            Console.WriteLine("Atvirkscias " + skaic.AtvirksciasSk()); // Išplėtimo metodai
           
            duom.SpausdIrSignal();    // Išplėtimo metodai. sveiki ir duom tipai skiariasi. Kintamasis taskas išplėtimo metodas       
            sveiki.SpausdIrSignal();

            var auto = new { Spalva = "Sidabrinė", Gamin = "Skoda", Greitis = 120 }; // Anoniminiai tipai
            Console.WriteLine("Jūsų {0} {1} spalvos auto važiuoja {2}", auto.Gamin, auto.Spalva, auto.Greitis);
            
            Console.ReadKey();

        }
    }
}
