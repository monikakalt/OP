﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4
{
    class Žaidėjas
    {
        public string numeris { get; set; } // Numeris ant marškinėlių  
        public string pavardė { get; set; } // Komandos žaidėjo pavardė  
        public string vardas { get; set; }  // Komandos žaidėjo vardas  
        public int ūgis { get; set; }       // Komandos žaidėjo ūgis 

        public Žaidėjas(string n, string p, string v, int u)
        {
            numeris = n;
            pavardė = p;
            vardas = v;
            ūgis = u;
        }
        public override string ToString()
        {
            string line = string.Format("{0, -10} {1, -20} {2}", vardas, pavardė, numeris);
            return line;
        }
    };
    class ProtokoloEilutė
    {
        public string numeris { get; set; } // Numeris ant marškinėlių  
        public int kėlinys { get; set; }    // Rungtynių kėlinys  
        public int pradžia { get; set; }    // Išėjimo į aikštelę laikas  
        public int trukmė { get; set; }     // Buvimo aikštelėje laikas 
        
        public ProtokoloEilutė(string n, int k, int p, int t)
        {
            numeris = n;
            kėlinys = k;
            pradžia = p;
            trukmė = t;
        }
        public override string ToString()
        {
            string line = string.Format("{0, -10}", trukmė);
            return line;
        }
    };  
    class Program
    {
        static void Main(string[] args)
        {
            List<Žaidėjas> k = new List<Žaidėjas>();
            List<ProtokoloEilutė> p = new List<ProtokoloEilutė>();

            k.Add(new Žaidėjas("10", "Vitkauskas", "Mantas", 185));
            k.Add(new Žaidėjas("9", "Valabciunas", "Jonas", 205));
            k.Add(new Žaidėjas("8", "Kazlauskas", "Algis", 190));
            k.Add(new Žaidėjas("7", "Jasikevicius", "Sarunas", 189));

            p.Add(new ProtokoloEilutė("10", 1, 4, 6));
            p.Add(new ProtokoloEilutė("10", 4, 6, 3));
            p.Add(new ProtokoloEilutė("8", 1, 5, 5));
            p.Add(new ProtokoloEilutė("7", 1, 2, 8));

            int sum = 0;

            IEnumerable<int> x10 = p.Where(o => o.numeris == "10").Select(o => o.trukmė);

            foreach (int x in x10)
            {
                sum += x;

            }

            Console.WriteLine("Suma lygu: {0, -10}", sum);

            IEnumerable<ProtokoloEilutė> x5 = p.Where(o => o.kėlinys == 1 && o.trukmė >= 5).Select(o => o);

            List<ProtokoloEilutė> Rikiuot = (from ar in x5
                                             orderby ar.trukmė
                                             select ar).Reverse<ProtokoloEilutė>().ToList<ProtokoloEilutė>();

         //   Rikiuot = Rikiuot.Reverse<ProtokoloEilutė>().ToList<;

            for (int i = 0; i < Rikiuot.Count(); i++)
            {
                for (int j = 0; j < k.Count(); j++)
                {
                    if (k[j].numeris == Rikiuot[i].numeris)
                    {
                        Console.WriteLine("{0} {1} {2} {3}", k[j].pavardė, k[j].vardas, k[j].numeris, Rikiuot[i].trukmė);
                    }
                }
            }

            Console.ReadKey();
        }
    }
}
