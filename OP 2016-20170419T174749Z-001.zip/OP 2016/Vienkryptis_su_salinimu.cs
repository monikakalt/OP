﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace u_duotys
{
    //Kiek kas pasakojo,kad buvo užduotis (1-moji)
    //Vienkryptis šąrašas su realiojo tipo skaičiais ir reikėjo padaryti neigiamų skaičių šalinimą.

    class Vienkryptis_su_salinimu
    {
    }

	/* ----------------------------------------------------------------------------------------------------------------------------------
	Susietą sąrašą galima skaldyti į tris lygius:
	1. Informacijos lygis - tai klasė kurioje laikomi visi reikalingi kintamieji vienam sąrašo elementui
	2. Mazgo lygis - tai klasė kuri turi informacijos klasę ir adresus į kitus elementus(mūsų kasdienybėje dažniausiai vieną)
	3. Sąrašo lygis - tai klasė kuri turi pagrindinį mazgą(pradžios), kitus(darbinius) mazgus ir metodus skirtus to sąrašo manipuliacijai
	Aukštesnio lygio klasė visada manipulioja arba saugo žemesnio lygio klasę.
	
	BTW programavime yra du pagrindiniai skaičių tipai:
	* Sveikieji (rekomenduoju int)
	* Realieji (rekomenduoju float, nes double yra daugeliu atvejų atminties švaistymas)
	---------------------------------------------------------------------------------------------------------------------------------- */

	// Perrašykime tavo bandymą į teisingą, beveik universalų variantą

	// Informacijos klasė (1 lygis)
	class Informacija
	{
		public float Skaičius { get; set; }

		public Informacija(float skaičius)
		{
			Skaičius = skaičius;
		}
	}

	// Mazgo klasė (2 lygis)
	class Mazgas
	{
		public Informacija Info { get; set; }
		public Mazgas Sekantis { get; set; }

		public Mazgas(int duomenys)						// Toks konstruktorius naudojamas tiesioginio sąrašo kūrime
		{
			Duomenys = duomenys;
			Sekantis = null;
		}

		public Mazgas(int duomenys, Mazgas sekantis)	// Toks konstruktorius naudojamas atvirkštinio sąrašo kūrime
		{
			Duomenys = duomenys;
			Sekantis = sekantis;
		}

		// Egzamine rašyk vieną konstruktorių!!!
	}

	// Sąrašo klasė (3 lygis)
	class Sąrašas
	{
		Mazgas pradžia;		// A.K.A. 'pr'
		Mazgas pabaiga;     // A.K.A. 'pb'
		Mazgas darbinis;    // A.K.A. 'd'

		public Sąrašas()
		{
			pradžia = pabaiga = darbinis = null;
		}

		public void Pradžia() { darbinis = pradžia; }
		public void Kitas() { darbinis = darbinis.Sekantis; }
		public bool Yra() { return darbinis != null; }
		public Informacija Imti() { return darbinis.Info; }
		
		// Šalinimas
		public void ŠalintiNeigiamus()
		{
			/*
			Šalinimą darysime su rodyklėmis. Surasime mazgą, kurio sekantis mazgas neatitinka kriterijų ir pirmojo mazgo rodyklę, 
			rodančią į nereikalingą mazgą, nukelsime į mazgą, einantį po antrojo mazgo.

			Pradedam eiti per sąrašą nuo pradžių
			Kadangi mes visada tikrinsim sekančio mazgo duomenis, cikle taip pat turime tikrinti ar sekantis mazgas egzistuoja
			*/
			for (Mazgas mazgas = Pradžia(); mazgas.Sekantis != null; Kitas())
			{
				// Tikrinam ar sekantis mazgas neatitinka kriterijų
				if (mazgas.Sekantis.Info < 0)
				{
					// paslenkam sekančio objekto rodyklę vienu mazgu toliau
					mazgas.Sekantis = mazgas.Sekantis.Sekantis;
				}
			}
		}
	}


    //Trečias klausimas
    //TEORIJA

    //1. Kas yra kodo kontraktai ?

    //2. Kokius žinote nuoseklinimo formatus?
    /*•	Dvejetainis (klasė BinaryFormatter);
    •	XML (klasė SoapFormatter);
    •	JSON(klasė DataContractJsonSerializer);
    •	Vartotojo sukurtas.
    */

    //3. Kokie yra sąsajų ir abstrakčių klasių skirtumai?
    /*Sąsaja neturi kodo, tik apibrėžia metodus ir savybes, kurias turi įgyvendinti paveldinti klasė, 
      naudojant sąsają, pilnai atskiriami paskelbimai nuo įgyvendinimū. 
      Abstrakčios klasės taip pat leidžia skelbti virtualius metodus be jų įgyvendinimo. 
      Abstrakčių klasių metodų įgyvendinimas galimas paveldėjimo grandinėje, kaip ir sąsajos metodų. 
      Galima paveldėti daug sąsajų, bet kuri klasė gali įgyvendinti bet kurią sąsają, paveldint sąsajas, klasės nesudaro medžio. */

    //4. Išimties sekimas ciklui ir ciklo viduje.?
    /*Jeigu išimtis tikrinama ciklo viduje, tai įvykdomi ciklo reikalavimai bei pritaikoma išimtis. 
    Jei išimtis vykdoma visam ciklui, ciklas gali nevykti, jeigu neatitinka išimties.*/
}
